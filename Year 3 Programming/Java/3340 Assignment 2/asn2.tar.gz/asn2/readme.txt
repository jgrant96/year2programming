Justin Grant
250787131
type 'asn2' to compile and run the java program
To use a argument/parameter simply write the file name afterwards
for example do:
"asn2 infile"
