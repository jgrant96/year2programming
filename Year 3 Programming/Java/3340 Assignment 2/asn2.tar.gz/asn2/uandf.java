//Justin Grant
//Student Number 250787131
public class uandf {

	private int [] ufdtArray;
	private int [] rank;
	private boolean finalized=false;
	// Constructs a union-find data type with n elements 1...n
	public uandf(int n){
		ufdtArray = new int [n];
		rank = new int [n];
	}
	
	//Creates a new set whose only member (and thus respectively) is i.
	public void makeSet(int i){
		ufdtArray[i] = i;
	}
	
	//Unites the dynamic sets that contain i and j respectively, into a new set that is a union of the two sets
	public void unionSets(int i, int j){
		i = findSet(i);
		j = findSet(j);
		if (rank[i] > rank[j])
		{
			ufdtArray[j] = ufdtArray[i];
		}
		else if (rank[i] < rank[j])
		{
			ufdtArray[i] = ufdtArray[j];
		}
		else
		{
			ufdtArray[j] = ufdtArray[i];
			rank[i] = rank[i] + 1;
		}
		
	}
	
	//returns the respective set containing i
	public int findSet(int i){
		if (finalized == false){
			if (ufdtArray[i] != i){
				return (ufdtArray[i] = findSet(ufdtArray[i]));
			}
			else return i;
		}
		else return ufdtArray[i];
	}

	
	//returns the current number of sets, finalizes the current sets (which means makeSet and unionSet will
	//not do anything after this operation. It resets the representatives so 1 to finalSets will be used
	//as representatives
	public int finalSets(){
		
		int count = 1;
		
		for (int i = 1; i < ufdtArray.length; i++){
			if (ufdtArray[i] != 0){
				findSet(i);
			}
		}
		
		for (int i = 1; i < ufdtArray.length; i++){
			if (ufdtArray[i] == i){
				ufdtArray[i] = count;
				rank[i] = 1;
				count++;
			}
			else{
				rank[i]=0;
			}
		}
		for (int i = 1; i<ufdtArray.length; i++)
			if (rank[i]==0 && ufdtArray[i] > 0)
				ufdtArray[i] = ufdtArray[ufdtArray[i]];
		finalized = true;
		return (count - 1);
	}
}
