//Justin Grant
//Student Number 250787131

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;


public class BinaryImageReader {
	public static void main (String[] args){

		//get the File name
		String fileName = args[0];
		String line = null;
		int [][] matrix = new int[71][71];
		//Try to open the file
		try {
			//Create a matrix to store the image

			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			int lineNumber = 0;

			//read each line from the image and check every character
			System.out.println("File Opened Successfully");
			while((line = bufferedReader.readLine()) != null){
				for (int count = 0; count < line.length(); count++){
					if (line.charAt(count) == '+')
						matrix[lineNumber][count] = 1;
					else
						matrix[lineNumber][count] = 0;
				}
				lineNumber++;
			}
			bufferedReader.close();
		}
		catch(FileNotFoundException ex){
			System.out.println("Unable to open file '" + fileName + "'");
		}
		catch (IOException ex){
			System.out.println("Error reading file '" + fileName + "'");

		}

		System.out.println("File Matrix Creation Complete");
		//We have now stored the image inside of matrix
		//Now we output the actual image

		for (int i = 0; i < matrix.length; i++){
			for (int j = 0; j < matrix.length; j++ ){
				if (matrix[i][j] == 1)
					System.out.print("+");
				else
					System.out.print(" ");
			}
			System.out.println("");
		}

		System.out.println("Image is now displayed on screen");

		//Now that we must create and initialize the union find graphing of the map
		uandf mapping = new uandf(matrix.length * matrix.length + 1);
		for (int i = 0; i < matrix.length; i++){
			for (int j = 0; j < matrix.length; j++){
				if (matrix[i][j] == 1){
					mapping.makeSet(i * matrix.length + j + 1);
					if (j > 0 && matrix[i][j-1] == 1)
						mapping.unionSets(i * matrix.length + j, i * matrix.length + j + 1);
					if (i > 0 && matrix[i-1][j] == 1)
						mapping.unionSets((i-1)*matrix.length + j + 1, i*matrix.length + j + 1);
				}
			}
		}

		System.out.println("UnionFind graphing of the map is initialized");

		//The UnionFind should now be initialized so we can do things with it.


		//First we'll finalize it
		int [] eachSet = new int [mapping.finalSets()];

		System.out.println("UnionFind Graph is now finalized");

		//PART 2
		//Now we're output the image but every connected component has a different letter
		int printIntr = 0;
		char printChar;
		for (int i = 0; i < matrix.length; i++){
			for (int j = 0; j < matrix.length; j++){
				printIntr = mapping.findSet(i * matrix.length + j);
				if (printIntr > 0){
					printChar = ((char) (printIntr + 64));

					System.out.print(printChar);
					eachSet[printIntr - 1]++;
				}
				else
					System.out.print(" ");
			}
			System.out.println("");
		}
		System.out.println("");
		//PART 3
		// Next we need to sort the array. This way we can tell how many of each component there are.
		int [] sortedArray = new int[matrix.length*matrix.length];
		for (int i = 0; i < matrix.length; i++)
			for (int j = 0; j < matrix.length; j++)
				sortedArray[i*matrix.length + j] = mapping.findSet(i*matrix.length + j);

		Arrays.sort(sortedArray);

		//Now that it's sorted we'll be able to output a list sorted by component size
		int compCount = 1;
		int previousNum = sortedArray[0];
		for (int i = 1; i < sortedArray.length; i++){
			if (previousNum == sortedArray[i] && i != sortedArray.length -1)
				compCount++;
			else
			{
				System.out.println ("Component Label: " + previousNum +"_ Size: " + compCount);
				compCount = 1;
				previousNum = sortedArray[i];
			}
		}

		//Part 4
		//Now we print the connected component, but labeled with unique character, but only those that
		//have size 3 or greater
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				printIntr = mapping.findSet(i * matrix.length + j + 1) + 64;
				if (printIntr == 64 || eachSet[printIntr - 65] <= 2)
					System.out.print(' ');
				else
					System.out.print((char) printIntr);
			}
			System.out.println();
		}
		System.out.println();
	}
}
