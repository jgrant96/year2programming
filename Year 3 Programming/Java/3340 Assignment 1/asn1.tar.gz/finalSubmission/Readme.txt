Justin Grant
250787131

Make sure you have the correct permissions to execute the scripts
try 'chmod 777 asn1_a'
and
try 'chmod 777 asn1_b'

type "asn1_a" in *nix to run the first java program, when you are in the directory that the .java files are.

"asn1_b" for the second java program.

use something that can run csh shell, and make sure java is configured properly.
