README

In order to run the program ensure mullevel_queue_CPU_...txt is in the same directory.
Run the program using the command ./Assign2

Or compile the program using gcc "3305Assignment2.c" -o DesiredExecutableName

and run it with ./DesiredExecutableName
